from turtle import Turtle

class Scoreboard(Turtle):
    def __init__(self):
        """ Initializes the scoreboard as a turtle."""
        super().__init__()
        self.score = 0
        self.color("black")
        self.hideturtle()
        self.penup()
        self.goto(100, 260)
        self.update_scoreboard()


    def update_scoreboard(self):
        """ Updates the scoreboard."""
        self.clear() # clear it first
        self.write(f"Score: {self.score}", align="center", font=("Arial", 24, "bold"))


    def increase_score(self):
        """ Increases the score by 1."""
        self.score += 1
        self.update_scoreboard()

    def reset(self):
        """ Rests the scoreboard to 0"""
        self.score = 0
        self.update_scoreboard()

    def game_over(self):
        self.clear()
        self.write("GAME OVER", align="center", font=("Arial", 24, "bold"))