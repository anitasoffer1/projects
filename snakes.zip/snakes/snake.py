from turtle import Turtle

class Snake:
    def __init__(self):
        """ Initialize the snake. """
        self.segments = []
        self.create_starting_snake()
        self.head = self.segments[0] # set head after snake is created

    def create_starting_snake(self):
        """ Creates a snake with 3 segments in starting position."""
        for i in range(3):
            segment = Turtle(shape='square')
            self.segments.append(segment)

        # start the head at (0,0)
        segment_pos_x = 0
        segment_pos_y = 0
        for segment in self.segments:
            segment.penup()
            segment.setheading(0)
            segment.goto(segment_pos_x, segment_pos_y)
            segment_pos_x -= 20 # put the next segment 20px to the left


    def move(self):
        """ Moves the snake forward by moving each segment to the place of the segment ahead of it."""
        for segment in range(len(self.segments)-1, 0, -1): # run the loop backwards
            new_x, new_y = self.segments[segment - 1].pos() # new position is the position of the one ahead of it
            self.segments[segment].goto(new_x, new_y)
        self.head = self.segments[0]
        self.head.forward(20)


    def grow(self):
        """Grows the snake's segments"""
        new_segment = Turtle(shape='square')
        new_segment.penup() # ensures it won't draw lines

        # place new segments where tail used to be before next move
        tail = self.segments[-1]
        new_segment.goto(tail.pos())

        # add the new segment to the list
        self.segments.append(new_segment)

    def reset(self):
        """ Resets the snake to its starting position by deleting the segments and creating a new one."""
        for segment in self.segments: # hide all previous segments
            segment.hideturtle()
        self.segments = []
        self.head = None
        self.create_starting_snake() # start a new snake


    def left(self):
        """ Changes snake direction left."""
        if self.head.heading() != 0: # only if snake wasn't previously headed in the opposite direction
            self.head.setheading(180)


    def right(self):
        """ Changes snake direction right."""
        if self.head.heading() != 180: # only if snake wasn't previously headed in the opposite direction
            self.head.setheading(0)


    def up(self):
        """ Changes snake direction up."""
        if self.head.heading() != 270: # only if snake wasn't previously headed in the opposite direction
            self.head.setheading(90)


    def down(self):
        """ Changes snake direction down."""
        if self.head.heading() != 90: # only if snake wasn't previously headed in the opposite direction
            self.head.setheading(270)



