from turtle import Turtle, Screen
from game_controller import GameController
from snake import Snake
from food import Food
from scoreboard import Scoreboard


def main():
    """ Set up objects and run the game. """
    my_snake = Snake()
    my_food = Food()
    my_score = Scoreboard()
    screen = Screen()
    game = GameController(my_score, my_food, my_snake, screen)

    game.run_game_loop()


    game.screen.exitonclick()

if __name__ == '__main__':
    main()