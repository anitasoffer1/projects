from snake import Snake
from food import Food
from scoreboard import Scoreboard
import time
from turtle import Screen


class GameController:
    """ Initialize the game controller """
    def __init__(self, scoreboard: Scoreboard, food: Food, snake: Snake, screen):
        self.scoreboard = scoreboard
        self.food = food
        self.snake = snake
        self.screen = screen
        self.setup_bindings()
        self.is_game_on = True


    def setup_bindings(self):
        """ Setup the screen and event listeners. """
        #screen setup
        self.screen.setup(800, 600)
        self.screen.bgcolor("blue")
        self.screen.title("Snakes")
        self.screen.tracer(0)
        self.screen.listen()

        #onkey listeners
        self.screen.onkey(self.snake.up, "Up")
        self.screen.onkey(self.snake.down, "Down")
        self.screen.onkey(self.snake.left, "Left")
        self.screen.onkey(self.snake.right, "Right")


    def run_game_loop(self):
        """ Main loop of the game controller."""
        while self.is_game_on:
            time.sleep(0.2) # Delay the animation to make the game a playable speed.
            self.screen.update()
            self.snake.move() # snake moves continuously
            if self.check_food_collision():
                self.snake.grow()
                self.food.refresh() # move the food after collision
                self.scoreboard.increase_score()
            if self.check_wall_collision() or self.check_self_collision(): # end the game if snake collides with the wall or itself
                self.end_game()

    def check_food_collision(self):
        """ Check if the food is collided with the snake's body. """
        if self.snake.head.distance(self.food) < 20:
            return True
        return False

    def check_wall_collision(self):
        """ Check if the wall collides with the snake's body. """
        head_x, head_y = self.snake.head.pos()
        if head_x >= 380 or head_x <= -380 or head_y >= 280 or head_y <= -280:
            return True
        return False

    def check_self_collision(self):
        """ Check if the snake's head collides with the snake's body. """
        head_x, head_y = self.snake.head.pos()
        for segment in self.snake.segments[1:]:
            x, y = segment.pos()
            if head_x == x and head_y == y:
                return True
        return False

    def end_game(self):
        """ Ends the game loop. """
        self.is_game_on = False
        self.scoreboard.game_over()

