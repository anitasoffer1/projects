import random
from turtle import Turtle

class Food(Turtle):
    """Initializes the food as a red turtle."""
    def __init__(self):
        super().__init__()
        self.penup()
        self.shape("circle")
        self.color("red")

    def refresh(self):
        """Moves the food to a new random position."""
        position = self.random_position()
        self.goto(position)

    def random_position(self):
        """ Returns a valid position."""
        position = (random.randint(-350, 350), random.randint(-250, 250)) # valid positions with margin
        return position